# Invoicey FinTech
### Requirements
You're required to install python3.8 upward
- Python("https://python.org")
## To run
Locate the directory where the app.py is found
```
pip install -r requirements.txt
export FLASK_APP="app.py"
flask run
```
